
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class GamePanel extends JPanel{
    private TopPanel top;
    private JButton player, opp1, opp2, opp3, lez, rez, topOOB, botOOB;
    
    GamePanel(TopPanel top){
        super();
        setLayout(null);
        setBackground(new Color(80,200,100));
        this.top = top;
        
        player = new JButton();
        opp1 = new JButton();
        opp2 = new JButton();
        opp3 = new JButton();
        lez = new JButton();
        rez = new JButton();
        topOOB = new JButton();
        botOOB = new JButton();
        
        add(player);
        add(opp1);
        add(opp2);
        add(opp3);
        add(lez);
        add(rez);
        add(topOOB);
        add(botOOB);
    }
    
    public JButton getPlayerButton(){
        return player;
    }
    public JButton getOpp1Button(){
        return opp1;
    }
    public JButton getOpp2Button(){
        return opp2;
    }
    public JButton getOpp3Button(){
        return opp3;
    }
    public JButton getLEZ(){
        return lez;
    }
    public JButton getREZ(){
        return rez;
    }
    public JButton gettopOOB(){
        return topOOB;
    }
    public JButton getbotOOB(){
        return botOOB;
    }
}
