
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class InitialFrame extends JFrame{
    
    private InitialPanel initialPanel;
    
    InitialFrame(String title){
        super(title);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(1200, 800);
        
        initialPanel = new InitialPanel();
        add(initialPanel);
        
        
        
        setVisible(true);
    }
    
    public InitialPanel getInitialPanel(){
        return initialPanel;
    }
}
