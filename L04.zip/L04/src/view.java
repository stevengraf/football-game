/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class view {
    InitialFrame initialFrame;
    
    view(){
        initialFrame = new InitialFrame("Football Game");
    }
    
    public InitialFrame getInitialFrame(){
        return initialFrame;
    }
}
