
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.Timer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class TopPanel extends JPanel{
    private JButton start, slow, medium, fast;
    private JLabel score, status, timer;
    private JSlider slider;
    
    TopPanel(){
        super();
        GridLayout lay1 = new GridLayout(2, 4, 5, 5);
        setLayout(lay1);
        
        start = new JButton("Start");
        slow = new JButton("Slow");
        medium = new JButton("Medium");
        fast = new JButton("Fast");
        
        score = new JLabel("Player: 0    Opponent: 0");
        status = new JLabel("Game status");
        
        
        timer = new JLabel("Time: 0");
        
        slider = new JSlider(5, 25, 15);
        slider.setMajorTickSpacing(10);
        slider.setMinorTickSpacing(1);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        
        
        add(start);
        add(slow);
        add(medium);
        add(fast);
        add(status);
        add(score);
        add(slider);
        add(timer);
    }
    
    public JButton getStartButton(){
        return start;
    }
    public JButton getSlowButton(){
        return slow;
    }
    public JButton getMediumButton(){
        return medium;
    }
    public JButton getFastButton(){
        return fast;
    }
    public JLabel getStatus(){
        return status;
    }
    public JLabel getScore(){
        return score;
    }
    public JSlider getSlider(){
        return slider;
    }
    public JLabel getTimerLabel(){
        return timer;
    }
}
