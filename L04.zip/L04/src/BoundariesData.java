/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Steven
 */
public class BoundariesData {
    private int boundsX, boundsY;
    
    BoundariesData(int boundsX, int boundsY){
        this.boundsX = boundsX;
        this.boundsY = boundsY;
    }
    
    public int getboundsX(){
        return boundsX;
    }
    
    public int getboundsY(){
        return boundsY;
    }
}
