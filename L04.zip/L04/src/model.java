/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class model {
    private PlayerData data;
    private OppData opp1Data, opp2Data, opp3Data;
    private BoundariesData oob1, oob2, ez1, ez2;
    private GameData gameData;
    
    model(){
        data = new PlayerData(10, 200, 300);
        opp1Data = new OppData(10, 800, 300);
        opp2Data = new OppData(10, 800, 500);
        opp3Data = new OppData(10, 800, 100);
        ez1 = new BoundariesData(0, 0);
        ez2 = new BoundariesData(1030, 0);
        oob1 = new BoundariesData(150,0);
        oob2 = new BoundariesData(150, 630);
        gameData = new GameData();
    }
    
    public PlayerData getPlayerData(){
        return data;
    }
    public OppData getOpp1Data(){
        return opp1Data;
    }
    public OppData getOpp2Data(){
        return opp2Data;
    }
    public OppData getOpp3Data(){
        return opp3Data;
    }
    public BoundariesData getOOB1(){
        return oob1;
    }
    public BoundariesData getOOB2(){
        return oob2;
    }
    public BoundariesData getEZ1(){
        return ez1;
    }
    public BoundariesData getEZ2(){
        return ez2;
    }
    public GameData getGameData(){
        return gameData;
    }
}
