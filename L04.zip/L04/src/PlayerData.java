/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class PlayerData {
    private int playerSpeed;
    private int startX;
    private int startY;
    private int pX;
    private int pY;
    
    PlayerData(int speed, int startX, int startY){
        playerSpeed = speed;
        this.startX = startX;
        this.startY = startY;
        this.pX = startX;
        this.pY = startY;
    }
    
    public int getSpeed(){
        return playerSpeed;
    }
    public void setPlayerSpeed(int change){
        playerSpeed = change;
    }
    public int getStartX(){
        return startX;
    }
    public int getStartY(){
        return startY;
    }
    public int getPlayerX(){
        return pX;
    }
    public void setPlayerX(int change){
        pX = change;
    }
    public int getPlayerY(){
        return pY;
    }
    public void setPlayerY(int change){
        pY = change;
    }
}
