/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class OppData {
    private int startX, startY, oppX, oppY, speed;
    
    OppData(int oppSpeed, int startX, int startY){
        this.startX = startX;
        this.startY = startY;
        oppX = startX;
        oppY = startY;
        speed = oppSpeed;
    }
    
    public int getOppStartX(){
        return startX;
    }
    public int getOppX(){
        return oppX;
    }
    public void setOppX(int change){
        oppX = change;
    }
    public int getOppStartY(){
        return startY;
    }
    public int getOppY(){
        return oppY;
    }
    public void setOppY(int change){
        oppY = change;
    }
    public int getOppSpeed(){
        return speed;
    }
    public void setOppSpeed(int change){
        speed = change;
    }
}
