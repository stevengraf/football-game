
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javafx.beans.value.ObservableValue;
import javax.swing.JSlider;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class control{
    private model model;
    private view view;
    private Timer gameTimer, oppTimer, collTimer;
    
    control(model modelParameter, view viewParameter){
        model = modelParameter;
        view = viewParameter;
        
        //setting bounds of buttons
        view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().setBounds(model.getPlayerData().getStartX(), model.getPlayerData().getStartY(), 50, 50);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp1Button().setBounds(model.getOpp1Data().getOppStartX(), model.getOpp1Data().getOppStartY(), 50, 50);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp2Button().setBounds(model.getOpp2Data().getOppStartX(), model.getOpp2Data().getOppStartY(), 50, 50);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp3Button().setBounds(model.getOpp3Data().getOppStartX(), model.getOpp3Data().getOppStartY(), 50, 50);
        view.getInitialFrame().getInitialPanel().getGamePanel().getLEZ().setBounds(model.getEZ1().getboundsX(), model.getEZ1().getboundsY(), 150, 650);
        view.getInitialFrame().getInitialPanel().getGamePanel().getREZ().setBounds(model.getEZ2().getboundsX(), model.getEZ2().getboundsY(), 150, 650);
        view.getInitialFrame().getInitialPanel().getGamePanel().gettopOOB().setBounds(model.getOOB1().getboundsX(), model.getOOB1().getboundsY(), 880, 20);
        view.getInitialFrame().getInitialPanel().getGamePanel().getbotOOB().setBounds(model.getOOB2().getboundsX(), model.getOOB2().getboundsY(), 880, 20);
        
        //setting colors of buttons
        view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().setBackground(Color.red);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp1Button().setBackground(Color.blue);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp2Button().setBackground(Color.blue);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp3Button().setBackground(Color.blue);
        view.getInitialFrame().getInitialPanel().getGamePanel().getLEZ().setBackground(new Color(000,100,250));
        view.getInitialFrame().getInitialPanel().getGamePanel().getREZ().setBackground(new Color(000,100,250));
        view.getInitialFrame().getInitialPanel().getGamePanel().gettopOOB().setBackground(Color.white);
        view.getInitialFrame().getInitialPanel().getGamePanel().getbotOOB().setBackground(Color.white);
        
        
        gameTimer = new Timer(1000, new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                model.getGameData().increaseTimer();
                view.getInitialFrame().getInitialPanel().getTopPanel().getTimerLabel().setText("Time: " + model.getGameData().getTimerVal());
            }
        });
        
        //opponent movement
        oppTimer = new Timer(500, new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                //x value for player position
                int xc = model.getPlayerData().getPlayerX();
                int oc = model.getOpp1Data().getOppX();
                int oc2 = model.getOpp2Data().getOppX();
                int oc3 = model.getOpp3Data().getOppX();
                int speed = model.getOpp1Data().getOppSpeed();

                //changing x position for opponents
                if (xc > oc) {
                    oc += speed;
                }
                if (xc < oc) {
                    oc -= speed;
                }
                if (xc > oc2) {
                    oc2 += speed;
                }
                if (xc < oc2) {
                    oc2 -= speed;
                }
                if (xc > oc3) {
                    oc3 += speed;
                }
                if (xc < oc3) {
                    oc3 -= speed;
                }

                //y value for player position
                int yc = model.getPlayerData().getPlayerY();
                int oyc = model.getOpp1Data().getOppY();
                int oyc2 = model.getOpp2Data().getOppY();
                int oyc3 = model.getOpp3Data().getOppY();

                //changing y position for opponents
                if (yc > oyc) {
                    oyc += speed;
                }
                if (yc < oyc) {
                    oyc -= speed;
                }
                if (yc > oyc2) {
                    oyc2 += speed;
                }
                if (yc < oyc2) {
                    oyc2 -= speed;
                }
                if (yc > oyc3) {
                    oyc3 += speed;
                }
                if (yc < oyc3) {
                    oyc3 -= speed;
                }
                

                model.getOpp1Data().setOppX(oc);
                model.getOpp1Data().setOppY(oyc);
                model.getOpp2Data().setOppX(oc2);
                model.getOpp2Data().setOppY(oyc2);
                model.getOpp3Data().setOppX(oc3);
                model.getOpp3Data().setOppY(oyc3);

                //change the bounds every timer tick
                view.getInitialFrame().getInitialPanel().getGamePanel().getOpp1Button().setBounds(model.getOpp1Data().getOppX(), model.getOpp1Data().getOppY(), 50, 50);
                view.getInitialFrame().getInitialPanel().getGamePanel().getOpp2Button().setBounds(model.getOpp2Data().getOppX(), model.getOpp2Data().getOppY(), 50, 50);
                view.getInitialFrame().getInitialPanel().getGamePanel().getOpp3Button().setBounds(model.getOpp3Data().getOppX(), model.getOpp3Data().getOppY(), 50, 50);
            }
        });
        
        
        //timer to check for collision
        collTimer = new Timer(10, new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                if ((view.getInitialFrame().getInitialPanel().getGamePanel().getOpp1Button().getBounds().intersects(view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().getBounds()))
                  ||(view.getInitialFrame().getInitialPanel().getGamePanel().getOpp2Button().getBounds().intersects(view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().getBounds()))
                  ||(view.getInitialFrame().getInitialPanel().getGamePanel().getOpp3Button().getBounds().intersects(view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().getBounds()))){
                    
                    model.getGameData().increaseOppScore();
                    model.getGameData().setStatus("Tackled!");
                    reset();
                    
                }
                if (view.getInitialFrame().getInitialPanel().getGamePanel().getREZ().getBounds().intersects(view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().getBounds())){
                    
                    model.getGameData().increasePlayerScore();
                    model.getGameData().setStatus("Touchdown!");
                    reset();
                    
                }
                if ((view.getInitialFrame().getInitialPanel().getGamePanel().gettopOOB().getBounds().intersects(view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().getBounds()))
                   ||view.getInitialFrame().getInitialPanel().getGamePanel().getbotOOB().getBounds().intersects(view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().getBounds())){
                    
                    model.getGameData().increaseOppScore();
                    model.getGameData().setStatus("Out of bounds!");
                    reset();
                    
                }
                
                view.getInitialFrame().getInitialPanel().getTopPanel().getStatus().setText(model.getGameData().getStatus());
                view.getInitialFrame().getInitialPanel().getTopPanel().getScore().setText("Player: " + model.getGameData().getPlayerScore() + "    Opponent: " + model.getGameData().getOppScore());
            }
        });
        

        //player movement
        view.getInitialFrame().getInitialPanel().getGamePanel().addKeyListener(new KeyAdapter(){
            public void keyPressed(KeyEvent ke) {
                int key = ke.getKeyCode();
                if (key == ke.VK_LEFT) {
                    model.getPlayerData().setPlayerX(model.getPlayerData().getPlayerX() - model.getPlayerData().getSpeed());
                }
                if (key == ke.VK_RIGHT) {
                    model.getPlayerData().setPlayerX(model.getPlayerData().getPlayerX() + model.getPlayerData().getSpeed());
                }
                if (key == ke.VK_UP) {
                    model.getPlayerData().setPlayerY(model.getPlayerData().getPlayerY() - model.getPlayerData().getSpeed());
                }
                if (key == ke.VK_DOWN) {
                    model.getPlayerData().setPlayerY(model.getPlayerData().getPlayerY() + model.getPlayerData().getSpeed());
                }
                view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().setBounds(model.getPlayerData().getPlayerX(), model.getPlayerData().getPlayerY(), 50, 50);
            }
        });
        
        
        view.getInitialFrame().getInitialPanel().getTopPanel().getSlider().addChangeListener(new ChangeListener(){
            public void stateChanged(ChangeEvent e){
                JSlider source = (JSlider)e.getSource();
                if (!source.getValueIsAdjusting()) {
                    model.getOpp1Data().setOppSpeed((int)source.getValue());
                    model.getOpp2Data().setOppSpeed((int)source.getValue());
                    model.getOpp3Data().setOppSpeed((int)source.getValue());
                    view.getInitialFrame().getInitialPanel().getGamePanel().requestFocusInWindow();
                }
            }
        });
        


        view.getInitialFrame().getInitialPanel().getTopPanel().getSlowButton().addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                model.getPlayerData().setPlayerSpeed(5);
                view.getInitialFrame().getInitialPanel().getGamePanel().requestFocusInWindow();
            }
        });
        view.getInitialFrame().getInitialPanel().getTopPanel().getMediumButton().addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                model.getPlayerData().setPlayerSpeed(10);
                view.getInitialFrame().getInitialPanel().getGamePanel().requestFocusInWindow();
            }
        });
        view.getInitialFrame().getInitialPanel().getTopPanel().getFastButton().addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                model.getPlayerData().setPlayerSpeed(15);
                view.getInitialFrame().getInitialPanel().getGamePanel().requestFocusInWindow();
            }
        });

        
        //start timers here
        view.getInitialFrame().getInitialPanel().getTopPanel().getStartButton().addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
            reset();
            gameTimer.start();
            oppTimer.start();
            collTimer.start();
            view.getInitialFrame().getInitialPanel().getGamePanel().requestFocusInWindow();
            }
        });
    }
    
    public void reset(){
        view.getInitialFrame().getInitialPanel().getGamePanel().getPlayerButton().setBounds(model.getPlayerData().getStartX(), model.getPlayerData().getStartY(), 50, 50);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp1Button().setBounds(model.getOpp1Data().getOppStartX(), model.getOpp1Data().getOppStartY(), 50, 50);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp2Button().setBounds(model.getOpp2Data().getOppStartX(), model.getOpp2Data().getOppStartY(), 50, 50);
        view.getInitialFrame().getInitialPanel().getGamePanel().getOpp3Button().setBounds(model.getOpp3Data().getOppStartX(), model.getOpp3Data().getOppStartY(), 50, 50);
        model.getPlayerData().setPlayerX(model.getPlayerData().getStartX());
        model.getPlayerData().setPlayerY(model.getPlayerData().getStartY());
        model.getOpp1Data().setOppX(model.getOpp1Data().getOppStartX());
        model.getOpp1Data().setOppY(model.getOpp1Data().getOppStartY());
        model.getOpp2Data().setOppX(model.getOpp2Data().getOppStartX());
        model.getOpp2Data().setOppY(model.getOpp2Data().getOppStartY());
        model.getOpp3Data().setOppX(model.getOpp3Data().getOppStartX());
        model.getOpp3Data().setOppY(model.getOpp3Data().getOppStartY());
        model.getGameData().resetTimer();
    }

    
}
