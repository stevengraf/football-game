
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class InitialPanel extends JPanel{
    private TopPanel top;
    private GamePanel game;
    
    InitialPanel(){
        super();
        setBackground(Color.gray);
        setLayout(new BorderLayout());
        
        top = new TopPanel();
        add(top, BorderLayout.NORTH);
        
        game = new GamePanel(top);
        add(game, BorderLayout.CENTER);
    }
    
    public TopPanel getTopPanel(){
        return top;
    }
    public GamePanel getGamePanel(){
        return game;
    }
}
