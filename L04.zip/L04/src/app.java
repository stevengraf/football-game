/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class app {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        model modelClass = new model();
        view viewClass = new view();
        control controlClass = new control(modelClass, viewClass);
    }
    
}
