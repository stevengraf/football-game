/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class GameData {
    private int i, playerScore, oppScore;
    private String status;
    
    GameData(){
        i = 0;
        playerScore = 0;
        oppScore = 0;
    }
    
    public int getPlayerScore(){
        return playerScore;
    }
    public void increasePlayerScore(){
        playerScore += 1;
    }
    public void setPlayerScore(int change){
        playerScore = change;
    }
    public int getOppScore(){
        return oppScore;
    }
    public void increaseOppScore(){
        oppScore += 1;
    }
    public void setOppScore(int change){
        oppScore = change;
    }
    public String getStatus(){
        return status;
    }
    public void setStatus(String change){
        status = change;
    }
    public int getTimerVal(){
        return i;
    }
    public void increaseTimer(){
        i += 1;
    }
    public void resetTimer(){
        i = 0;
    }
}
